package com.example.notes_maker

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.example.notes_maker.R
import com.google.android.material.snackbar.Snackbar

class SavedNotes : AppCompatActivity() {

    private lateinit var courseRV: RecyclerView
    private lateinit var courseRVAdapter: CourseAdapter
    private lateinit var courseList: ArrayList<CourseModal>
    private lateinit var sharedPreferences: SharedPreferences

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_saved_notes)

        // Initialize RecyclerView and its adapter
        courseRV = findViewById(R.id.idRVCourses)
        courseList = ArrayList()
        courseRVAdapter = CourseAdapter(courseList, this)
        courseRV.adapter = courseRVAdapter

        // Set up ItemTouchHelper
        ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.RIGHT) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                // this method is called when the item is moved.
                return false
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                // this method is called when we swipe our item to right direction.
                // on below line we are getting the item at a particular position.
                val deletedCourse: CourseModal = courseList[viewHolder.adapterPosition]
                val position = viewHolder.adapterPosition
                courseList.removeAt(viewHolder.adapterPosition)
                courseRVAdapter.notifyItemRemoved(viewHolder.adapterPosition)

                Snackbar.make(
                    courseRV,
                    "Deleted " + deletedCourse.courseName,
                    Snackbar.LENGTH_LONG
                )

                removeFromSharedPreferences(deletedCourse.courseName)
            }
        }).attachToRecyclerView(courseRV)

        // Retrieve data from SharedPreferences
        sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
        retrieveDataFromSharedPreferences()

        // Notify adapter that data set has changed
        courseRVAdapter.notifyDataSetChanged()
    }

    private fun retrieveDataFromSharedPreferences() {
        // Clear the existing courseList before adding new data
        courseList.clear()

        // Retrieve the size of the data list from SharedPreferences
        val size = sharedPreferences.getInt("dataListSize", 0)

        // Loop through the saved data and add it to the courseList
        for (i in 0 until size) {
            val courseName = sharedPreferences.getString("courseName_$i", "")
            // Ensure courseName is not empty and not already in courseList before adding it
            if (!courseName.isNullOrEmpty() && !courseList.any { it.courseName == courseName }) {
                courseList.add(CourseModal(courseName))
            }
        }
    }

    private fun removeFromSharedPreferences(courseName: String) {
        val editor = sharedPreferences.edit()
        // Retrieve the size of the data list from SharedPreferences
        var size = sharedPreferences.getInt("dataListSize", 0)
        // Loop through the saved data and remove the item with matching courseName
        for (i in 0 until size) {
            val storedCourseName = sharedPreferences.getString("courseName_$i", "")
            if (storedCourseName == courseName) {
                // Shift the subsequent items to fill the gap
                for (j in i until size - 1) {
                    val nextCourseName = sharedPreferences.getString("courseName_${j + 1}", "")
                    editor.putString("courseName_$j", nextCourseName)
                }
                // Clear the last item
                editor.remove("courseName_${size - 1}")
                size -= 1
                editor.putInt("dataListSize", size)
                editor.apply()
                // Update the RecyclerView after each deletion
                courseRVAdapter.notifyDataSetChanged()
                break
            }
        }
    }

}
