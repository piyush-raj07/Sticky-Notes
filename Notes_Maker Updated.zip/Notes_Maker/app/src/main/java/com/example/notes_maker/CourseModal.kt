package com.example.notes_maker

import android.media.Image

data class CourseModal (

    var courseName: String


)