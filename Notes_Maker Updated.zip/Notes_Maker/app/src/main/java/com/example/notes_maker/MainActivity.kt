package com.example.notes_maker
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.notes_maker.R
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

    private lateinit var editTextNote: EditText
    lateinit var courseList: ArrayList<CourseModal>
    private lateinit var sharedPreferences: SharedPreferences


    @SuppressLint("WrongViewCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize the courseList
        courseList = ArrayList()

        editTextNote = findViewById(R.id.editTextNote)
        sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)

        val fabAddNote: FloatingActionButton = findViewById(R.id.fabAddNote)
        fabAddNote.setOnClickListener {
            if (editTextNote.visibility == View.VISIBLE) {
                editTextNote.visibility = View.GONE
            } else {
                editTextNote.visibility = View.VISIBLE
            }
        }

        val saveBtn: Button = findViewById(R.id.savebutton)
        saveBtn.setOnClickListener {
            val editTextValue = editTextNote.text.toString()
            if (editTextValue.isNotEmpty()) {

                courseList.add(CourseModal(editTextValue))
                saveDataToSharedPreferences(courseList)
                Toast.makeText(this,"Data Saved",Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Please enter the note", Toast.LENGTH_SHORT).show()
            }
        }

        val clearBtn: Button = findViewById(R.id.clearbutton)
        clearBtn.setOnClickListener {
            editTextNote.text.clear()
        }

        val savedNotesButton: Button = findViewById(R.id.savesnotes)
        savedNotesButton.setOnClickListener {

            Toast.makeText(this, "Saved Notes is opening", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, SavedNotes::class.java))
        }
    }

    private fun saveDataToSharedPreferences(newDataList: ArrayList<CourseModal>) {
        val oldDataList = retrieveDataFromSharedPreferences()
        val mergedDataList = ArrayList<CourseModal>()
        mergedDataList.addAll(oldDataList)
        mergedDataList.addAll(newDataList)

        val editor = sharedPreferences.edit()
        editor.putInt("dataListSize", mergedDataList.size)
        for (i in mergedDataList.indices) {
            editor.putString("courseName_$i", mergedDataList[i].courseName)
           // editor.putInt("imageResource_$i", mergedDataList[i].courseImg)
        }
        editor.apply()
    }

    private fun retrieveDataFromSharedPreferences(): ArrayList<CourseModal> {
        val dataList = ArrayList<CourseModal>()
        val size = sharedPreferences.getInt("dataListSize", 0)
        for (i in 0 until size) {
            val courseName = sharedPreferences.getString("courseName_$i", "") ?: ""
          //  val imageResource = sharedPreferences.getInt("imageResource_$i", 0)
            dataList.add(CourseModal(courseName))
        }
        return dataList
    }

}

